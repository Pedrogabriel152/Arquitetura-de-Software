import express from 'express';

const app = express();
const port = 5000;

app.get('/', (_req: any, res: any) => {
  res.send('Hello TypeScript + Node.js!');
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
